-------------------------
What is this?
-------------------------
This is a Discord Spammer, which you can use to raid servers/troll your friends/wake up your friends

- ⚠ WARNING!
This program is against Discord ToS!!! But there is a small chance of getting perm banned.

-------------------------
How to start?
-------------------------
1. Go to config.json
2. In "TOKENHERE" paste your bot's token
3. In "YOURIDHERE" paste your discord ID
4. Open the file in Windows CMD - You can simply use VSC for this ~~ https://code.visualstudio.com/
5. In cmd type "npm install" and wait till its done.
6. When everything is done - Type "node ." in cmd and have fun!